import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Instagram,
  Facebook,
  Twitter,
  Mail,
  Phone,
  MapPin,
  Camera,
  Heart,
  Clock,
  PawPrintIcon as Paw,
} from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Paw className="h-6 w-6 text-pink-500" />
            <span className="text-xl font-bold text-pink-600">Click Patinhas</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="#inicio" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Início
            </Link>
            <Link href="#sobre" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Sobre
            </Link>
            <Link href="#portfolio" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Portfólio
            </Link>
            <Link href="#depoimentos" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Depoimentos
            </Link>
            <Link href="#contato" className="text-sm font-medium hover:text-pink-600 transition-colors">
              Contato
            </Link>
          </nav>
          <Button variant="outline" size="sm" className="md:hidden">
            Menu
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section id="inicio" className="relative py-20 md:py-32 bg-gradient-to-b from-pink-50 to-white">
          <div className="container flex flex-col md:flex-row items-center gap-8 md:gap-16">
            <div className="flex-1 space-y-4 text-center md:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-pink-700">
                Eternize momentos especiais com seu pet
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground">
                Fotografias profissionais que capturam a personalidade e o amor do seu melhor amigo
              </p>
              <Button size="lg" className="bg-pink-600 hover:bg-pink-700 mt-4">
                Agende uma sessão
              </Button>
            </div>
            <div className="flex-1 relative">
              <div className="relative h-[300px] md:h-[400px] w-full rounded-2xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Pets felizes em sessão de fotos"
                  fill
                  className="object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-pink-500/20 to-transparent"></div>
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white p-3 rounded-full shadow-lg">
                <Paw className="h-8 w-8 text-pink-500" />
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-[url('/placeholder.svg?height=20&width=1200')] bg-repeat-x opacity-10"></div>
        </section>

        {/* Sobre Nós */}
        <section id="sobre" className="py-16 md:py-24">
          <div className="container">
            <div className="flex flex-col md:flex-row items-center gap-8 md:gap-16">
              <div className="flex-1 relative">
                <div className="relative h-[300px] md:h-[400px] w-full rounded-2xl overflow-hidden shadow-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Fotógrafo com pets"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                  <Camera className="h-10 w-10 text-pink-500" />
                </div>
              </div>
              <div className="flex-1 space-y-6">
                <div>
                  <h2 className="text-3xl md:text-4xl font-bold text-pink-700 mb-2">Sobre Nós</h2>
                  <div className="w-20 h-1 bg-pink-300 rounded-full"></div>
                </div>
                <p className="text-lg text-muted-foreground">
                  O Click Patinhas é um estúdio especializado em fotografia pet, criado com amor e dedicação para
                  registrar momentos únicos dos seus companheiros de quatro patas.
                </p>
                <p className="text-lg text-muted-foreground">
                  Nossa equipe trabalha com paciência, carinho e técnicas especiais para capturar a verdadeira essência
                  e personalidade do seu pet, criando memórias que durarão para sempre.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                  <div className="flex flex-col items-center p-4 bg-pink-50 rounded-lg">
                    <Heart className="h-8 w-8 text-pink-500 mb-2" />
                    <h3 className="font-medium">Amor pelos Pets</h3>
                  </div>
                  <div className="flex flex-col items-center p-4 bg-pink-50 rounded-lg">
                    <Camera className="h-8 w-8 text-pink-500 mb-2" />
                    <h3 className="font-medium">Profissionalismo</h3>
                  </div>
                  <div className="flex flex-col items-center p-4 bg-pink-50 rounded-lg">
                    <Clock className="h-8 w-8 text-pink-500 mb-2" />
                    <h3 className="font-medium">Paciência</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Portfólio */}
        <section id="portfolio" className="py-16 md:py-24 bg-pink-50">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-pink-700 mb-2">Nosso Portfólio</h2>
              <div className="w-20 h-1 bg-pink-300 rounded-full mx-auto"></div>
              <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
                Confira alguns dos nossos trabalhos e deixe-se encantar pela magia que capturamos em cada clique
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((item) => (
                <div
                  key={item}
                  className="group relative overflow-hidden rounded-xl shadow-md transition-all hover:shadow-xl"
                >
                  <div className="relative h-64 w-full overflow-hidden">
                    <Image
                      src={`/placeholder.svg?height=300&width=400&text=Pet ${item}`}
                      alt={`Foto de pet ${item}`}
                      fill
                      className="object-cover transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end">
                    <div className="p-4 text-white">
                      <h3 className="font-medium">Sessão Pet {item}</h3>
                      <p className="text-sm opacity-80">Fotografia profissional</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-10">
              <Button variant="outline" className="border-pink-300 text-pink-700 hover:bg-pink-100">
                Ver mais fotos
              </Button>
            </div>
          </div>
        </section>

        {/* Depoimentos */}
        <section id="depoimentos" className="py-16 md:py-24">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-pink-700 mb-2">Depoimentos</h2>
              <div className="w-20 h-1 bg-pink-300 rounded-full mx-auto"></div>
              <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
                Veja o que nossos clientes têm a dizer sobre nossas sessões fotográficas
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  name: "Ana Silva",
                  pet: "Luna",
                  text: "Simplesmente amei as fotos da minha Luna! A equipe foi super paciente e carinhosa, conseguindo capturar a personalidade brincalhona dela. Recomendo demais!",
                },
                {
                  name: "Carlos Oliveira",
                  pet: "Thor",
                  text: "Meu Thor é um cachorro muito agitado, mas os fotógrafos do Click Patinhas souberam como acalmá-lo e fazer fotos incríveis. O resultado superou todas as expectativas!",
                },
                {
                  name: "Mariana Costa",
                  pet: "Mia e Bob",
                  text: "Fiz uma sessão com meus dois gatos e fiquei encantada com o resultado. As fotos capturam perfeitamente a personalidade de cada um. Já estou planejando a próxima sessão!",
                },
              ].map((depoimento, index) => (
                <div key={index} className="bg-white p-6 rounded-xl shadow-md">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="h-12 w-12 rounded-full overflow-hidden bg-pink-100 flex items-center justify-center">
                      <Paw className="h-6 w-6 text-pink-500" />
                    </div>
                    <div>
                      <h3 className="font-medium">{depoimento.name}</h3>
                      <p className="text-sm text-muted-foreground">Tutor(a) de {depoimento.pet}</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground">"{depoimento.text}"</p>
                  <div className="mt-4 flex text-yellow-400">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <svg
                        key={star}
                        xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="lucide lucide-star"
                      >
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                      </svg>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contato */}
        <section id="contato" className="py-16 md:py-24 bg-pink-50">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-pink-700 mb-2">Entre em Contato</h2>
              <div className="w-20 h-1 bg-pink-300 rounded-full mx-auto"></div>
              <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
                Estamos ansiosos para criar memórias incríveis com você e seu pet
              </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              <div className="bg-white p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-medium mb-4">Envie uma mensagem</h3>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="nome" className="block text-sm font-medium mb-1">
                      Nome
                    </label>
                    <Input id="nome" placeholder="Seu nome" />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">
                      E-mail
                    </label>
                    <Input id="email" type="email" placeholder="seu@email.com" />
                  </div>
                  <div>
                    <label htmlFor="mensagem" className="block text-sm font-medium mb-1">
                      Mensagem
                    </label>
                    <Textarea id="mensagem" placeholder="Como podemos ajudar?" rows={4} />
                  </div>
                  <Button className="w-full bg-pink-600 hover:bg-pink-700">Enviar mensagem</Button>
                </form>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-md">
                <h3 className="text-xl font-medium mb-4">Informações de contato</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-pink-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">E-mail</h4>
                      <p className="text-muted-foreground">contato@clickpatinhas.com.br</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="h-5 w-5 text-pink-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">WhatsApp</h4>
                      <p className="text-muted-foreground">(11) 99999-9999</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-pink-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium">Endereço</h4>
                      <p className="text-muted-foreground">Rua das Patinhas, 123 - São Paulo, SP</p>
                    </div>
                  </div>
                  <div className="pt-4">
                    <h4 className="font-medium mb-2">Redes Sociais</h4>
                    <div className="flex gap-4">
                      <Link
                        href="#"
                        className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center hover:bg-pink-200 transition-colors"
                      >
                        <Instagram className="h-5 w-5 text-pink-600" />
                      </Link>
                      <Link
                        href="#"
                        className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center hover:bg-pink-200 transition-colors"
                      >
                        <Facebook className="h-5 w-5 text-pink-600" />
                      </Link>
                      <Link
                        href="#"
                        className="h-10 w-10 rounded-full bg-pink-100 flex items-center justify-center hover:bg-pink-200 transition-colors"
                      >
                        <Twitter className="h-5 w-5 text-pink-600" />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t py-8 bg-white">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Paw className="h-5 w-5 text-pink-500" />
              <span className="text-lg font-medium text-pink-600">Click Patinhas</span>
            </div>
            <div className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} Click Patinhas. Todos os direitos reservados.
            </div>
            <div className="flex gap-4">
              <Link href="#" className="text-muted-foreground hover:text-pink-600 transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-pink-600 transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-pink-600 transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
